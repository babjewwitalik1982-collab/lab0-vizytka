# Лабораторна робота 0 — Візитна картка

Тема: «Візитна картка Олександра Усика»

Технології:
- HTML5
- CSS3
- Bootstrap 5.3

## Як опублікувати на GitHub Pages

1. Увійдіть у GitHub.
2. Створіть новий репозиторій, наприклад `lab0-vizytka`.
3. Завантажте в репозиторій файли `index.html` та `style.css`.
4. Відкрийте Settings → Pages.
5. У розділі Build and deployment виберіть:
   - Source: Deploy from a branch
   - Branch: main
   - Folder: / (root)
6. Натисніть Save.
7. Через деякий час GitHub покаже адресу сторінки.

Типовий формат:
https://ВАШ_ЛОГІН.github.io/lab0-vizytka/

Саме це веб-посилання потрібно прикріпити до лабораторної роботи.
